//
//  ViewController.m
//  test
//
//  Created by Yinchuan Zhou on 3/29/16.
//  Copyright © 2016 Yinchuan Zhou. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *MyImageWindow;
@property (weak, nonatomic) IBOutlet UIButton *OutLetButton;
@property (weak, nonatomic) IBOutlet UIButton *outletButton;
@property(assign)int indexNumber;
- (IBAction)commonTap_Pressed:(UIButton *)sender;
- (IBAction)ImageEnable_Switch:(UISwitch *)sender;
@property (weak, nonatomic) IBOutlet UISwitch *Switch_Hidden;

@property(strong)NSArray*ImageArray;

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    _MyImageWindow.image = [UIImage imageNamed:@"Image1.jpg"];
    _ImageArray = [NSArray arrayWithObjects:
                [UIImage imageNamed:@"Image1.jpg"],
                [UIImage imageNamed:@"Image2.jpg"],
                [UIImage imageNamed:@"Image3.jpg"],
                [UIImage imageNamed:@"Image4.jpg"],
                [UIImage imageNamed:@"Image5.jpg"],
                [UIImage imageNamed:@"Image6.jpg"],
                [UIImage imageNamed:@"Image7.jpg"],
                [UIImage imageNamed:@"Image8.jpg"],
                [UIImage imageNamed:@"Image9.jpg"],
                [UIImage imageNamed:@"Image10.jpg"],nil];

    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)ImageEnable_Switch:(UISwitch *)sender {
    
    UISwitch * temp = sender;
    if (temp.on) {
        _OutLetButton.hidden = false;
        _outletButton.hidden = false;
        _MyImageWindow.hidden = false;
     
    }else{
        _OutLetButton.hidden = true;
        _outletButton.hidden = true;
        _MyImageWindow.hidden = true;


    }
}




- (IBAction)commonTap_Pressed:(UIButton *)sender
{
//    NSLog(@"%d",_indexNumber);
    _Switch_Hidden.hidden = false;
    _outletButton.enabled = true;
    if (sender.tag) {
        _indexNumber++;
    } else {
        _indexNumber--;
    }

    if (_indexNumber==10) {
        
         UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Image is over" preferredStyle:UIAlertControllerStyleActionSheet];
        UIAlertAction *alertOK = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action)
                                  {

                                  }];
        [alertController addAction:alertOK];
        [self presentViewController:alertController animated:YES completion:nil];
        _indexNumber--;
    }
    else if(_indexNumber==-1){
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Image is over" preferredStyle:UIAlertControllerStyleActionSheet];
        UIAlertAction *alertOK = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action)
                                  {
                                      
                                  }];
        [alertController addAction:alertOK];
        [self presentViewController:alertController animated:YES completion:nil];
        _indexNumber++;
        
    }else{
    
    _MyImageWindow.image =[_ImageArray objectAtIndex:_indexNumber];
    
    }
    
}


    


@end
